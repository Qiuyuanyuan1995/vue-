<template>
  <div id="app">
    <div class="content">
        <app-header></app-header>
        <!-- <app-addBlog></app-addBlog> -->
        <!-- <app-showBlog></app-showBlog> -->
        <router-view></router-view>
    </div>

  </div>
  

</template>

<script>

import Header from './components/Header'
import AddBlog from './components/AddBlog'
import ShowBlog from './components/ShowBlog'

export default {
  name: "App",
  components: {
    "app-header":Header,
    "app-addBlog":AddBlog,
    "app-showBlog":ShowBlog,
  }
};
</script>

<style scoped>

</style>
