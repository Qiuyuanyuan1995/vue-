import ShowBlog from './components/ShowBlog'
import AddBlog from './components/AddBlog'
import SingleBlog from './components/SingleBlog'
import EditBlog from './components/EditBlog'

export const routes=[
    {path:"/",component:ShowBlog},
    {path:"/addBlog",component:AddBlog},
    {path:"/blog/:id",component:SingleBlog},//根据id跳转到对应信息
    {path:"/edit/:id",component:EditBlog},//根据id跳转到对应信息，后编辑(修改)
]