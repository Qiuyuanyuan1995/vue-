import Vue from 'vue'
import VueRouter from 'vue-router' //引入路由
import axios from 'axios' //引入axios（代替vue-resource）
import App from './App'
import {routes} from './routes'//导入路由的js文件

Vue.config.productionTip = false
Vue.use(VueRouter) //导入路由

//全局配置axios
Vue.prototype.$http = axios //导入axios

//<自定义指令：改变样式>
//自定义指令[改变颜色]
//el:元素
//binding:绑定，拿到传过来的参数
//wnode:虚拟节点
Vue.directive('rainbow',{
  bind(el,binding,wnode){
    // el.style.color="red";
    el.style.color='#' + Math.random().toString(16).slice(2,8);//随机颜色
  }
})

//自定义指令[改变长度]
Vue.directive('theme',{
  bind(el,binding,vnode){
    if(binding.value=='why'){
      el.style.maxWidth='1260px';
    }else if(binding.value=='narrow'){
      el.style.maxWidth="860px";
    }

    //binding.arg 是用来判断有没有参数
    if(binding.arg=='column'){
      el.style.background="#6677cc";
      el.style.padding="10px";
    }
  }
})


//<自定义过滤器：改变行为>
//自定义过滤器[值改为大写]
Vue.filter("to-uppercase",function(value){
  return value.toUpperCase();//值改为大写
})

//自定义过滤器[截取字符串]
Vue.filter("snippet",function(value){
  return value.slice(0,100)+"...";//截取100个字符
})


//配置路由
const router = new VueRouter({
  routes,
  mode: "history",//#
});


new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>'
})
