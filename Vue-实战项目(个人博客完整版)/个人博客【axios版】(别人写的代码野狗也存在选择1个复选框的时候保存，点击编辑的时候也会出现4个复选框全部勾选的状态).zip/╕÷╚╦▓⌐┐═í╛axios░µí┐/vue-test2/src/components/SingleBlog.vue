<template>
  <div id="single-blog">
    <h3>{{blog.title}}</h3>
    <article>{{blog.content}}</article>
    <p>作者:{{blog.author}}</p>
    <p>分类:</p>
    <ul>
      <li v-for="ca in blog.categories" :key="ca.id">{{ca}}</li>
    </ul>
    <button @click="deleteSingleBlog()">删除</button>
    <router-link :to="'/edit/' + id">编辑</router-link>
  </div>
</template>

<script>
export default {
  name: "single-blog",
  data() {
    return {
      id: this.$route.params.id, //this.$route.params. 拿到当前对象的属性
      blog: {}
    };
  },
  created() {
    // get 从数据库中读取数据
    this.$http
      .get(
        "https://wd6831298446ycmyyj.wilddogio.com/posts/" + this.id + ".json"
      )
      .then((data)=> {
        console.log(data);
        this.blog = data.data;
      })
  },
  methods: {
    //删除信息
    deleteSingleBlog() {
      this.$http
        .delete(
          "https://wd6831298446ycmyyj.wilddogio.com/posts/" + this.id + ".json"
        )
        //删除之后跳转到主页面
        .then((response) => {
          this.$router.push({ path: '/' });
        });
    }
  }
};
</script>

<style scoped>
#single-blog {
  max-width: 960px;
  margin: 0 auto;
  padding: 20px;
  background: #eee;
  border: 1px dotted #aaa;
}
</style>


