<template>
  <div id="app-header">
    <nav>
        <ul>
            <li>
                <router-link to="/" exact>博客</router-link><!-- exact 点击其中一个,另一个消失，相互切换点击 -->
                <router-link to="/addBlog" exact>写博客</router-link>
            </li>
        </ul>
    </nav>
  </div>
</template>

<script>

export default {
  name: "app-header",

};
</script>

<style scoped>
#app-header nav{
    background: crimson;
    padding: 30px 0;
    margin-bottom: 40px;
}

#app-header nav ul{
    list-style-type: none;
    text-align: center;
    margin: 0;
}

#app-header nav ul li{
    display:inline-block;
    margin: 0 10px;
}


#app-header nav ul li a{/* <router-link> 默认为a标签*/
    color:#fff;
    text-decoration: none;
    padding: 12px;
    border-radius: 5px;
}

#app-header nav ul li .router-link-active{
    background: rgba(255, 255, 255, 0.8);
    color:#444;
}
</style>