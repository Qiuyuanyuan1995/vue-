<template>
  <div id="showBlog" v-theme:column="'narrow'">
    <!-- 自定义指令也可以带参数：v-theme:column="'narrow'"-->
    <div class="wrapper">
      <h1>
        <strong>博客总览</strong>
      </h1>
      <input type="text" v-model="search" placeholder="搜索" name id>
      <div v-for="b in filteredBlogs" :key="b.id" class="single-blog">
        <router-link :to="'/blog/'+b.id">
        <h2 v-rainbow>{{b.title | to-uppercase}}</h2>
        </router-link>
        <article>{{b.content | snippet}}</article>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "showBlog",
  data() {
    return {
      blogs: [],
      search: ""
    };
  },
  created() {
    // get 从数据库中读取数据
    this.$http.get("https://wd6831298446ycmyyj.wilddogio.com/posts.json") 
      .then((data)=> {
        // console.log(data);
        // this.blogs = data.body.slice(0, 10); //取十条数据
        return data.data;
      })

      .then((data)=>{
        var blogsArray=[];//保存每个对象的数组
        for(let key in data){
          data[key].id = key;//给每个对象添加id(这个key就是每次保存，自动生成的name)
          blogsArray.push(data[key]);
        }
        // console.log(blogsArray);//打印对象
        this.blogs = blogsArray;
        // console.log(this.blogs);
      })
  },
  //过滤数据，匹配搜索
  computed: {
    filteredBlogs: function() {
      return this.blogs.filter(blog => {
        return blog.title.match(this.search);
      });
    }
  },

};
</script>

<style  scoped>
#showBlog {
  max-width: 800px;
  margin: 0 auto;
}

#showBlog .wrapper input[type="text"]{
  padding: 8px;
  width: 100%;
  box-sizing: border-box;
}

#showBlog .wrapper .single-blog {
  padding: 20px;
  margin: 20px 0;
  box-sizing: border-box;
  background: #eee;
}

#showBlog .wrapper .single-blog a{ /* <router-link>标签默认为a标签 */
  color: #444;
  text-decoration: none;
}


</style>
