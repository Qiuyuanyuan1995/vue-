<template>
  <div id="add-blog">
    <div class="wrapper">
      <h2><strong>添加博客</strong></h2>
      <form action v-if="!blog.submmited">
        <label for>博客标题</label>
        <input type="text" v-model="blog.title" name id required>
        <br>
        <label for>博客内容</label>
        <textarea name id v-model="blog.content" cols="75" rows="5"></textarea>

        <div class="checkboxes">
          <!-- checkbox使用双向绑定,一定要设value,不然会出现,点击一个,全部选中或全部清空 -->
          <label for="vue">Vue.js</label>
          <input type="checkbox" id="vue" value="Vue.js" v-model="blog.categories">
          <label for="node">Node.js</label>
          <input type="checkbox" id="node" value="Node.js" v-model="blog.categories">
          <label for="react">React.js</label>
          <input type="checkbox" id="react" value="React.js" v-model="blog.categories">
          <label for="angular4">Angular4.js</label>
          <input type="checkbox" id="angular4" value="Angular4.js" v-model="blog.categories">
        </div>

        <div class="author">
          <label for>作者</label>
          <select v-model="blog.author">
            <option v-for="aut in blog.authors" :key="aut.id">{{aut}}</option>
          </select>
        </div>
        <button @click.prevent="post">添加博客</button>
      </form>
      <div v-if="blog.submmited">
        <h3>您的博客发布成功！</h3>
      </div>
      <hr>
      <div class="box">
        <h4><strong>博客总览</strong></h4>
        <p>博客标题：{{blog.title}}</p>
        <p>博客内容：</p>
        <p>{{blog.content}}</p>
        <p>博客分类:</p>
        <ul>
          <li v-for="cate in blog.categories" :key="cate.id">{{cate}}</li>
        </ul>
        <p>作者：{{blog.author}}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "add-blog",
  data() {
    return {
      blog: {
        title: "",
        content: "",
        categories: [], //因为是多选框，显示多个数据，所以定义数组
        authors: ["杰克", "汤姆", "张三"],
        author: "", //显示单个数据，定义属性
        submmited: false //你是否点击了提交事件
      }
    };
  },
  methods: {
    //https://jsonplaceholder.typicode.com/posts 网络资源地址（测试专用），后期换成数据库地址就行了
    // post 把数据保存到数据库中
    post: function() {
        this.$http.post("https://wd6831298446ycmyyj.wilddogio.com/posts.json",this.blog)//在线请求野狗数据库
          //直接把整个对象传过去this.blog
        //then方法:post成功之后返回对应的内容
        .then((data)=> {
          // console.log(data);
          this.blog.submmited = true;
        });
    }
  }
};
</script>

<style scoped>
#add-blog *{
  box-sizing: border-box;
}

#add-blog {
  margin: 20px auto;
  max-width: 600px;
  padding: 20px;
}


#add-blog .wrapper form label {
  display: block;
  margin: 20px 0 10px;
}

#add-blog .wrapper form input[type="text"]{
  display: block;
  width: 100%;
  padding: 8px;
}

#add-blog .wrapper .author select {
  display: block;
  width: 100%;
}

#add-blog .wrapper form .checkboxes label{
  display: inline-block;
  margin-top: 0;
}

#add-blog .wrapper form .checkboxes input[type="checkbox"]{
  display: inline-block;
  margin-right: 10px;
}

#add-blog .wrapper form button{
  display: block;
  margin: 20px 0;
  background: crimson;
  color: #fff;
  border: 0;
  padding: 14px;
  border-radius: 4px;
  font-size: 18px;
  cursor: pointer;
}

#add-blog .wrapper .box{
  padding: 10px 10px;
  border: 1px dotted #ccc;
  margin: 30px 0;
}
</style>


